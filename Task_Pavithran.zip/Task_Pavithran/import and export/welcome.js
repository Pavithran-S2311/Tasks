import {add, welcomeUser} from './add.js';
var res = add(5,5);
alert(res);

welcomeUser("Kumar");