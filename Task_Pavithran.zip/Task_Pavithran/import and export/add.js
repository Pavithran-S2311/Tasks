function add(a,b)
{
    return a + b;
}

function welcomeUser(name)
{
    alert('welcome '+name+" !");
}

export{add,welcomeUser};