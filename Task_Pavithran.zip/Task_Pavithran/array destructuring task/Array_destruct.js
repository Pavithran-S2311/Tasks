/* TASK- From above code snippet,get the value of c and use array destructuring 
and assign it to seperate variable and print them
 */
function add(a,b,...c)
{
    console.log('a= '+a);
    console.log('b= '+b);
    let[d,e,f,g,h] = c;
    console.log('d= '+d);
    console.log('e= '+e);
    console.log('f= '+f);
    console.log('g= '+g);
    console.log('h= '+h);
} 
add(1,2,3,4,5,6,7);
